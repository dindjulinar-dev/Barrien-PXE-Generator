wpeinit
ping 127.0.0.1
start X:\Windows\System32\install.cmd