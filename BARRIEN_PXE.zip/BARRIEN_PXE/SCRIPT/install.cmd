wpeutil SetKeyboardLayout 040c:0000040c
wpeutil InitializeNetwork
ipconfig

net use z: \\DJ-SRV\Winstall /user:DEPLOY@domain.local *
echo 
ping SRV

dir z: /s

z:\start_auto_install.cmd